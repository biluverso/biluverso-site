# Bilu Verso — site minimalista

Estrutura inicial do portal do **Bilu Verso** (estático, responsivo, pronto para deploy na **Vercel**).

## Estrutura
```
biluverso/
├── index.html
├── apps.html
├── videos.html
├── contato.html
└── assets/
    ├── css/style.css
    ├── js/script.js
    └── img/logo.svg
```

## Como publicar na Vercel
1) Crie um repositório no GitHub e envie estes arquivos (pasta `biluverso/`).  
2) Acesse https://vercel.com → **New Project** → importe o repositório.  
3) Depois do deploy, em **Settings → Domains**, adicione **biluverso.com.br**.  
4) No **registro.br**, coloque os DNS sugeridos pela Vercel (CNAME/ALIAS para `www` e raiz).

> Dica: os botões “Baixar” dos apps podem apontar para Google Drive, GitHub Releases, Mega, etc.

## Personalização rápida
- Troque o logo em `assets/img/logo.svg`
- Ajuste cores em `assets/css/style.css`
- Edite os links das redes em `contato.html`
- Em `videos.html`, substitua os IDs/URLs dos embeds.
