const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// Mobile nav toggle
const nav = document.querySelector('[data-nav]');
const btn = document.querySelector('.nav-toggle');
if (btn && nav){
  btn.addEventListener('click', () => {
    const open = nav.getAttribute('data-open') === 'true';
    nav.setAttribute('data-open', String(!open));
    btn.setAttribute('aria-expanded', String(!open));
  });
}

// Highlight active link
const links = document.querySelectorAll('.nav a');
const path = window.location.pathname.replace(/\/index\.html$/, '/');
links.forEach(a => {
  const href = a.getAttribute('href');
  const matchRoot = (href === '/' && (path === '/' || path === ''));
  const matchPage = (href !== '/' && path.endsWith(href));
  if (matchRoot || matchPage){ a.classList.add('is-active'); }
});
